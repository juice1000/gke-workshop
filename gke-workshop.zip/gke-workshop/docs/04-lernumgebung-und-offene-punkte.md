# 04 Lernumgebung und offene Punkte

## Lernumgebung

### Lokal (Tag 1, Teile von Tag 2)

- Docker und minikube (Docker-Treiber) auf den Rechnern der Teilnehmenden.
- Offen: Dürfen die Teilnehmenden Docker und minikube installieren? Gibt es einen Proxy, der Image-Pulls und Downloads blockiert? Läuft alles auf Firmenlaptops mit Einschränkungen?
- Klärung läuft mit Sascha Smolin (Ops).
- Wichtig: Der Setup-Check (Lab 0) am Anfang von Tag 1 fängt Probleme ab, ersetzt aber keine Vorabprüfung.

### Cloud (ab Tag 2 Nachmittag, Tag 3)

- Der IT-Dienstleister des Kunden stellt keine Sandbox rechtzeitig bereit.
- GitHub-Accounts sind laut Kunde machbar, Michael Tischler wünscht, dass alle vorab einen Account haben.
- Möglichkeit: eigenes Google-Cloud-Projekt von Look Beyond. Nicht geklärt ist, ob die Rechner der Teilnehmenden aus dem Firmennetz dorthin kommen (Netzwerkzugriff, Proxy, Sicherheitsrichtlinien) und wie Zugriffe und Kosten pro Person abgegrenzt werden (Namespace pro Person, IAM).
- Fallback, wenn keine Cloud erreichbar ist: GKE-Teile als geführte Demo durch den Trainer, Teilnehmende arbeiten weiter lokal. Dieser Fallback ist in den Lecturer-Notizen vorbereitet, aber noch nicht im Detail ausgearbeitet.

### GKE-Modus

Der Kunde plant mit Standard (ZIMDB Plus) und prüft Autopilot. Die Labs sind so geschrieben, dass sie in beiden Modi laufen sollen. Das ist noch nicht getestet.

## Offene Punkte

| Punkt | Wer | Status |
|---|---|---|
| Teilnehmerliste mit Rollen und Kenntnisstand | Kunde (Tischler, Blessing) | zugesagt, offen |
| Termine und Format (Präsenz oder remote) | Kunde | offen |
| Bestätigung der Schulung, Teilnehmerzahl | Kunde | offen, Interessentenabfrage läuft |
| Docker und minikube auf Teilnehmer-Rechnern, Proxy | Smolin | offen |
| Cloud-Sandbox oder eigenes Projekt, Netzwerkzugriff | Julien und Kunde | offen |
| GitHub-Accounts der Teilnehmenden | Kunde | als machbar bezeichnet |
| Vertragsweg (GFU oder direkt), Sprache der Unterlagen | Julien | offen |
| Zweiter Abstimmungstermin | Kunde schlägt vor | Einladung zugesagt |
| Agenda für Tag 1 bis 3 an Smolin | Julien | in Arbeit |

## Risiken

| Risiko | Gegenmaßnahme |
|---|---|
| Kein Cloud-Zugang | Demo-Fallback; lokale Labs sind eigenständig |
| Lokale Installation scheitert | Setup-Check, Vorabprüfung mit Smolin, ggf. vorbereitete Anleitung |
| Sehr gemischtes Niveau | Pufferzeiten, Zusatzaufgaben für Fortgeschrittene, Streichlisten |
| Zu viel Stoff | Kernprogramm klein halten, Optionales klar abgrenzen |
| Befehle und Labs ungetestet | Alles vor dem Workshop mit minikube und GKE durchspielen |
| Faktenstand | Nicht verifiziert (siehe unten) |

## Noch nicht verifiziert

Aus dem Gedächtnis geschrieben und vor dem Workshop gegen aktuelle Google-Dokumentation und per Test zu prüfen:

- Standardwerte der Probes (10 s, 1 s, 3, 0)
- Menünamen der Google-Cloud-Konsole und die Bezeichnung "Google Cloud Observability"
- Details zu Extended-Channel und Upgrade-Strategien von Node Pools
- Verhalten der JVM bei sehr kleinen Speicherlimits (Release B in Lab 5)
- Sichtbarkeit von Container-Restarts in den Metriken
- Label des CoreDNS-Pods (`k8s-app=kube-dns`)
- Mindestanforderungen von minikube an die Hardware
