# GKE Einführung: Workshop-Repository

Repository für den 3-tägigen Workshop "GKE Einführung" für Entwicklerinnen und Entwickler der S-Management Services GmbH (Sparkassen-Finanzgruppe). Durchführung durch Look Beyond (Julien). Grundlage ist der GFU-Kurs S5549, das Curriculum ist aber eigenständig.

Dieses Repository enthält zunächst die Dokumentation von Bedarf und Kontext. Später kommen die Übungsprojekte (Labs) dazu.

## Inhalt

| Datei | Zweck |
|---|---|
| [docs/01-kontext.md](docs/01-kontext.md) | Kunde, Ansprechpersonen, Technologie-Stack, Rahmenbedingungen |
| [docs/02-bedarf-und-lernziele.md](docs/02-bedarf-und-lernziele.md) | Was der Kunde braucht, Zielgruppe, Lernziele nach Tag 3 |
| [docs/03-curriculum-entscheidungen.md](docs/03-curriculum-entscheidungen.md) | Warum das Curriculum so aussieht, Abgrenzung zur GFU-Gliederung |
| [docs/04-lernumgebung-und-offene-punkte.md](docs/04-lernumgebung-und-offene-punkte.md) | Lokale und Cloud-Umgebung, Risiken, offene Fragen |
| [docs/05-gespraechsnotizen.md](docs/05-gespraechsnotizen.md) | Zusammenfassung des Vorgesprächs vom 1. Oktober 2026 |

## Geplante Struktur (noch nicht gebaut)

```
lab02-hallo-app/     Spring-Boot-Beispielanwendung, Dockerfile, k8s/ (Tag 1)
lab03-defekt/        fünf defekte Manifeste zur Fehlersuche (Tag 2)
lab04-gke/           erstes Deployment auf GKE (Tag 2)
lab05-abschluss/     Abschlussübung mit starter/ und releases/ (Tag 3)
```

## Wo liegt das Kursmaterial?

Das ausführliche Material (Kapitel pro Tag, Glossar, Cheat Sheet, Lecturer's Edition) liegt in Notion unter "Workshops > Google Kubernetes Engine". Dieses Repository dokumentiert den Hintergrund und enthält später den Code.

## Status

Entwurf, Stand 17.11.2026. Teilnehmerliste, Termine und Cloud-Zugang sind noch offen, siehe [docs/04-lernumgebung-und-offene-punkte.md](docs/04-lernumgebung-und-offene-punkte.md).
